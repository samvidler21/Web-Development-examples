<!DOCTYPE html>
<html>
<head>
	<title>Design Page</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
<h1>Database Design and Implementation</h1>
<h2>Database Tables</h2>
<h3>Books</h3>
<?php
try{
       $conn = new PDO('mysql:host=localhost;dbname=u1563107', 'u1563107', '28may97');
}
catch (PDOException $exception) 
{
	echo "Oh no, there was a problem" . $exception->getMessage();
}        
$query = "SELECT * FROM books";
$resultset = $conn->query($query);
echo "<table>";
echo "<tr><th>id</th><th>title</th><th>author</th><th>created_at</th><th>updated_at</th><th>genre_id</th><tr>";
while ($books = $resultset->fetch()) 
{
echo"<tr>";
echo "<td>".$books["id"]."</td>"; 
echo "<td>".$books["title"]."</td>"; 
echo "<td>".$books["author"]."</td>";
echo "<td>".$books["created_at"]."</td>";
echo "<td>".$books["updated_at"]."</td>";
echo "<td>".$books["genre_id"]."</td>";
echo "</tr>";
}
echo "</table>";
$conn=NULL;
?>
<h3>Genres</h3>
<?php
try{
       $conn = new PDO('mysql:host=localhost;dbname=u1563107', 'u1563107', '28may97');
}
catch (PDOException $exception) 
{
	echo "Oh no, there was a problem" . $exception->getMessage();
}

$query = "SELECT * FROM genres ";
$resultset = $conn->query($query);
echo "<table>";
echo "<tr><th>id</th><th>name</th><th>description</th><tr>";
while ($genres = $resultset->fetch())
{
echo"<tr>";
echo "<td>".$genres["id"]."</td>"; 
echo "<td>".$genres["name"]."</td>"; 
echo "<td>".$genres["description"]."</td>"; 
echo "</tr>";
}
echo "</table>";
$conn=NULL;
?>
</body>
</html>