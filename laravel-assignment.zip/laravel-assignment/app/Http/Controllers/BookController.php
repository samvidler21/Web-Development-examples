<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Book;

use App\Genre;

class BookController extends Controller
{
    function home()
    {
        return view('book/home');
    }
   function index()
    {
        $books = Book::all();
        return view('book/allbooks',['books' => $books]);
    }
    function details($bookId)
    {
        $book = Book::find($bookId);
        return view('book/details',['book' => $book]);
    }
    function addForm()
    {
        $genres = Genre::all();
        return view('book/addform',['genres'=>$genres]);
    }
    function addBook(Request $request)
    {
        $this->validate($request, [
            'title' => 'required|max:100',
            'author' => 'required|max:200',
            'genre' => 'required',
        ]);
        $book = new Book();
        $book->title = $request->title;
        $book->author=$request->author;

        $genre = Genre::find($request->genre);
        $book->genre()->associate($genre);

        $book->save();
        return redirect('all');
    }

    function deleteForm()
{
    $books = Book::all();
    return view('book/deleteform',['books' => $books]);
}

function deleteBooks(Request $request)
{
    Book::destroy($request->books);
    return redirect('all');
}
}
