<html>
    <head>
        <title>@yield('title')</title>
        <link href="{{asset('/css/style.css')}}" rel="stylesheet" type="text/css">
    </head>
    <body>
        @section('header')
            <ul>
                <li><a href="{{url('home')}}">Home</a></li>
                <li><a href="{{url('all')}}">View all Books</a></li>
                <li><a href="{{url('addform')}}">Add a Book</a></li>
                <li><a href="{{url('deleteform')}}">Delete Books</a></li>
            </ul>
        @show

        <div class="container">
            @yield('content')
        </div>
    </body>
</html>