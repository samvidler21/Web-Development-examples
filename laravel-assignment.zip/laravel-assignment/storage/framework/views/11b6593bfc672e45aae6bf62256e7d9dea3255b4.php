<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->stopSection(); ?>

    <h1>John Smith's Second Hand Bookshop Login Form</h1>


<form action="login_process.php" method="post">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username">
    <label for="password" >Password:</label>
    <input type="password" id="password" name="password">
    <input type="submit" name="login" value="Login">
</form>
<footer>John Smith's Second Hand Bookship Copyright @ 2017</footer>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>