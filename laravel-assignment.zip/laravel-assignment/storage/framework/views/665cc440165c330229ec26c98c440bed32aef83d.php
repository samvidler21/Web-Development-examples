<?php $__env->startSection('title', 'Database Tables'); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
    <h1>Database Tables</h1>
<h2>Books Table</h2>

<h2>Genres Table</h2>
<footer>John Smith's Second Hand Bookshop Copyright @ 2017</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>