<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" type="text/css">
    </head>
    <body>
        <?php $__env->startSection('header'); ?>
            <ul>
                <li><a href="<?php echo e(url('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('all')); ?>">View all Books</a></li>
                <li><a href="<?php echo e(url('addform')); ?>">Add a Book</a></li>
                <li><a href="<?php echo e(url('deleteform')); ?>">Delete Books</a></li>
            </ul>
        <?php echo $__env->yieldSection(); ?>

        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>