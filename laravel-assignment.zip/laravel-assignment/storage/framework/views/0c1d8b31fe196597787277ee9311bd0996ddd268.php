<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<section>
<h1>John Smith's Second Hand Bookshop</h1>
<p>Welcome to John Smith's Second Hand Bookshop. Use the links above to navigate yourself through the site.</p>
<footer>John Smith's Second Hand Bookshop Copyright @ 2017</footer>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>