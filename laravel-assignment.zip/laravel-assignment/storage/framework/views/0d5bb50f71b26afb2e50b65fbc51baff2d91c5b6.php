<?php $__env->startSection('title', 'Add a book'); ?>
<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>

<?php endif; ?>
<form action="<?php echo e(url('addbook')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<section>

<h1>Add a Book</h1>
<p>To add a book simply enter the boxes below and then click the add a book button.Once you have added a book click on view books to see the book you have added. Note, if you do not enter any data into the fields and click add a book you will get an error message.</p>
<div>
    <label for="title">Enter the title of a book:</label>
<input type="text" name="title" id="title">
</div>
<br>
<div>
<label for="title">Enter the author of the book:</label>
<input type="text" name="author" id="author">
</div>
<br>
<fieldset>
<legend>Select the book's genre</legend>
<?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <label for="dirBtn<?php echo e($genre->id); ?>">
        <input id="dirBtn<?php echo e($genre->id); ?>" type="radio" name="genre" value="<?php echo e($genre->id); ?>">
        <?php echo e($genre->name); ?>

        </label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</fieldset>
<br>
<input type="submit" name="submitBtn" value="Add a Book">
<br>
<br>
   <ul2>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li2><?php echo e($error); ?></li2>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul2>
<br>
<br>
<footer>John Smith's Second Hand Bookshop Copyright @ 2017</footer>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>