<?php $__env->startSection('title', 'Logout'); ?>

<?php $__env->startSection('content'); ?>
 <p>You've been logged out. Click the link below to log back in.</p>
 <p><a href='login'>Login again</a></p>
<footer>John Smith's Second Hand Bookship Copyright @ 2017</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>