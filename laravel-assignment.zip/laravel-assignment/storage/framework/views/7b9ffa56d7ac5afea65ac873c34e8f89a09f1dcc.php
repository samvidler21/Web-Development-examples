<?php $__env->startSection('title', 'Delete books'); ?>
<?php $__env->startSection('content'); ?>
<section>
<form action="<?php echo e(url('deletebooks')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <h1>Delete Books</h1>
    <p>To delete a book select the book you want to delete by clicking the box next to it and then click the delete books button at the bottom.</p>
     <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <label><?php echo e($book->title); ?></label>
            <input type='checkbox' value='<?php echo e($book->id); ?>' name='books[]'/>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
    <input type="submit" name="submitBtn" value="Delete Books">
</form>
<footer>John Smith's Second Hand Bookshop Copyright @ 2017</footer>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>