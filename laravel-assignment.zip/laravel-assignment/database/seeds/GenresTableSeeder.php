<?php

use Illuminate\Database\Seeder;

class GenresTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('genres')->insert(['name' => 'Horror','description' => 'Intended or has the capacity to frighten, scare, disgust or startle the reader.']);
        DB::table('genres')->insert(['name' => 'Action and Adventure','description' => 'Key element, overshadowing characters theme or setting. Adventure story is often man against nature.']);
        DB::table('genres')->insert(['name' => 'Fantasy','description' => 'Imaginary universe often but not always without either locations, events or people.']);
        DB::table('genres')->insert(['name' => 'Drama','description' => 'Normally a play containing conflict of charcters.']);
    }
}
