<?php

use Illuminate\Database\Seeder;

class BooksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert(['title' => 'Harry Potter and the Goblet of Fire','author' => 'JK Rowling', 'genre_id'=>1]);
        DB::table('books')->insert(['title' => 'Romeo and Juliet','author' => 'William Shakespeare', 'genre_id'=>4]);
        DB::table('books')->insert(['title' => 'Of Mice and Men','author' => 'John Steinbeck', 'genre_id'=>2]);
        DB::table('books')->insert(['title' => 'Charlie and the Chocolate Factory','author' => 'Roald Dahl', 'genre_id'=>3]);
    }
}